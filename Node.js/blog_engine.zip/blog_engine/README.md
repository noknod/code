Blog project for M101JS

./app.js - entry point
./package.json - npm package description
./posts.js - Posts Data Access Helper
./sessions.js - Sessions Data Access Helper
./users.js - Users Data Access Helper
./views/ - html templates

Getting started

npm install
node app.js
